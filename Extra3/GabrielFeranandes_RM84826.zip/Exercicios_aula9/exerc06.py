numAny = int(input("Informe o primeiro numero: "))
result = numAny % 2
if (result == 0):
    print("Esse numero {} é par".format(numAny))
elif (result == 1):
    print("Esse numero {} é ímpar".format(numAny))
