
num1 = int(input("Informe um numero: "))
num2 = int(input("Informe outro numero: "))

if (num1 == num2):
    print("Os numeros {} e {} são iguais".format(num1,num2))
else:
    print("Os numeros {} e {} são diferentes".format(num1,num2))