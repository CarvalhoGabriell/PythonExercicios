numero = int(input("Digite aqui um numero qualquer: "))


if (numero % 10 == 0):
    print("Esse número {} é multiplo de 5 e de 10".format(numero))
else:
    print("O número {} não é um multiplo de 5 ou de 10....".format(numero))