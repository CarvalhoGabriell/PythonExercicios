
senha = int(input("Por favor informe sua senha: "))

if(senha == 1214):
    print("Acesso permitido")
else:
    print("Acesso negado, você não tem permissão")