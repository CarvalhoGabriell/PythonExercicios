num1 = int(input("Informe um numero: "))
num2 = int(input("Informe outro numero: "))
result = num1 % num2
if (result == 0):
    print("Eles são divisíveis")
else:
    print("Eles não são divisíveis")