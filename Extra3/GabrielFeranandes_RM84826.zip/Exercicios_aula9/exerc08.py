
num1 = int(input("Informe um numero: "))
num2 = int(input("Informe outro numero: "))

resultado = num1 + num2

if (resultado >= 10):
    print("Numero {} é maior que 10".format(resultado))
else:
    print("O numero {} é menor que 10".format(resultado))